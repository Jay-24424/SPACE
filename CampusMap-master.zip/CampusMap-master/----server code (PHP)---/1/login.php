

<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Campus Map Server Login</title>

<!--Stylesheets-->
    <link rel="stylesheet" type="text/css" href="assets/css/login.css" />
 <link href="assets/css/clock.css" rel="stylesheet" type="text/css"/>
    		<!-- JavaScript Includes -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.0.0/moment.min.js"></script>
		<script src="assets/js/clock.js"></script>
        <script src="assets/js/jquery.shuffleLetters.js"></script>
        <script src="assets/js/shuttle.js"></script>
</head>

<body>

    <div id = "myheader"><h2>Campus Map Server</h2>
    </div>

    		

    <form id="login-register" action="index.php" method="post">
        <h1 id="container">Welcome!</h1>
        
        	   <div id="clock" class="dark">
 				<div class="ampm"></div>

				<div class="digits"></div>
                   <div class ="clear"></div>
		  </div>
            <input type="text" placeholder="Email" name="email"   id="smallwinEmail"  autofocus/><br/>
            <input type="password" placeholder="Password" id="passwordtmp"  name="password" /><br/>
            <button type="submit">Login</button>
 
        	<span><?php if(!empty($err)) echo $err; ?></span>
    </form>

</body>
</html>