<?php

    require_once("GoogleDistance.php");

    echo GetDistance(41.660715 ,	-91.53652, 41.660695 ,	-91.535656);

?>