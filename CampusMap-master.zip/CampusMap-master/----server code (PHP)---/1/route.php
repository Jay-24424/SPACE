<?php
class Route{
    
	public $start_lat;
	public $start_lng;
	public $end_lat;
	public $end_lng;
	public $distance;
    public $taketime;
    public $destination;
    public $filename;
    
	public function __construct($start_lat,$start_lng,$end_lat,$end_lng,$distance,$taketime,$destination,$filename){
		$this->start_lat=doubleval($start_lat);
        $this->start_lng=doubleval($start_lng);
        $this->end_lat=doubleval($end_lat);
        $this->end_lng=doubleval($end_lng);
        $this->distance=doubleval($distance);
        $this->taketime=intval($taketime);
        $this->destination=$destination;
        $this->filename=$filename;
	}
}
    
?>